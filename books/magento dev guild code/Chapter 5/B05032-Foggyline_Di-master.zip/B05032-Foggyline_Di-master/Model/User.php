<?php

namespace Foggyline\Di\Model;

class User implements \Foggyline\Di\Model\TestInterface
{

}
