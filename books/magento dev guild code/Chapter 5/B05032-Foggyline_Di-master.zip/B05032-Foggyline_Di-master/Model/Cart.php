<?php

namespace Foggyline\Di\Model;

class Cart implements \Foggyline\Di\Model\TestInterface
{

}
