<?php

namespace Foggyline\Di\Model;

interface TestInterface
{

}
