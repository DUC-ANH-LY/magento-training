<?php

namespace Foggyline\Di\Model;

class Image
{

}
