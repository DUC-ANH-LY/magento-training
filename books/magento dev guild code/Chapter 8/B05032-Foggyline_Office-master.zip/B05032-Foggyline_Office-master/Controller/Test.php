<?php

namespace Foggyline\Office\Controller;

abstract class Test extends \Magento\Framework\App\Action\Action
{
}
