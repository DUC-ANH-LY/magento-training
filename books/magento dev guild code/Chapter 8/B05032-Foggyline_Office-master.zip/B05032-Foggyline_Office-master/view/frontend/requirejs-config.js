var config = {
    map: {
        '*': {
            foggylineHello: 'Foggyline_Office/js/foggyline-hello'
        }
    }
};
