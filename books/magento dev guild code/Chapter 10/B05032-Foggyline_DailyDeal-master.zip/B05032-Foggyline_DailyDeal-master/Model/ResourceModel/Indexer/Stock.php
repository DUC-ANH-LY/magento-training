<?php

namespace Foggyline\DailyDeal\Model\ResourceModel\Indexer;

class Stock extends \Magento\CatalogInventory\Model\ResourceModel\Indexer\Stock\DefaultStock
{

}
