<?php

namespace Foggyline\DailyDeal\Model\ResourceModel\Indexer;

class Price extends \Magento\Catalog\Model\ResourceModel\Product\Indexer\Price\DefaultPrice
{

}
