<?php

namespace Foggyline\DailyDeal\Model\Product;

class Price extends \Magento\Catalog\Model\Product\Type\Price
{

}
